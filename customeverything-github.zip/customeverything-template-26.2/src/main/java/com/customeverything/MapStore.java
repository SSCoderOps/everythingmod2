package com.customeverything;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores the top-down colour of every chunk the player has seen (one int[256] of ARGB per chunk).
 * Used by both the minimap and the world map. A value of 0 means "not explored".
 */
public final class MapStore {
    private final Map<Long, int[]> chunks = new HashMap<>();
    private boolean dirty = false;

    private static long key(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xffffffffL);
    }

    /** ARGB colour of a block column, or 0 if never seen. */
    public int colorAt(int bx, int bz) {
        int[] c = chunks.get(key(bx >> 4, bz >> 4));
        if (c == null) return 0;
        return c[((bz & 15) << 4) | (bx & 15)];
    }

    /** Samples a loaded chunk and stores its colours. Returns false if the chunk isn't loaded. */
    public boolean scanChunk(ClientLevel level, int cx, int cz, int playerY) {
        LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
        if (chunk == null) return false;

        boolean ceiling = level.dimensionType().hasCeiling();
        int minY = level.getMinY();
        int[] out = new int[256];
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
                int y;
                if (ceiling) {
                    y = Math.min(playerY + 2, level.getMaxY());
                    // walk down from the player's height to the first solid block under air
                    while (y > minY) {
                        pos.set((cx << 4) + x, y, (cz << 4) + z);
                        BlockState s = chunk.getBlockState(pos);
                        if (!s.isAir() && s.getFluidState().isEmpty()) break;
                        y--;
                    }
                } else {
                    y = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
                }
                pos.set((cx << 4) + x, y, (cz << 4) + z);
                BlockState state = chunk.getBlockState(pos);
                int rgb = state.getMapColor(level, pos).col;
                if (rgb == 0) rgb = 0x000000;

                // simple relief shading using the block to the north
                int ny = y;
                if (z > 0) {
                    ny = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, x, z - 1) - 1;
                }
                float shade = ny > y ? 0.78f : (ny < y ? 1.18f : 1.0f);
                int r = Math.min(255, (int) (((rgb >> 16) & 255) * shade));
                int g = Math.min(255, (int) (((rgb >> 8) & 255) * shade));
                int b = Math.min(255, (int) ((rgb & 255) * shade));
                out[(z << 4) | x] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        chunks.put(key(cx, cz), out);
        dirty = true;
        return true;
    }

    public boolean isDirty() { return dirty; }

    public void save(File file) {
        try {
            file.getParentFile().mkdirs();
            try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
                out.writeInt(chunks.size());
                for (Map.Entry<Long, int[]> e : chunks.entrySet()) {
                    out.writeLong(e.getKey());
                    for (int v : e.getValue()) out.writeInt(v);
                }
            }
            dirty = false;
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static MapStore load(File file) {
        MapStore store = new MapStore();
        if (!file.exists()) return store;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int n = in.readInt();
            for (int i = 0; i < n; i++) {
                long k = in.readLong();
                int[] data = new int[256];
                for (int j = 0; j < 256; j++) data[j] = in.readInt();
                store.chunks.put(k, data);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return store;
    }
}
