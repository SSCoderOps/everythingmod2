package com.customeverything;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;

/**
 * Fullscreen world map. Drag with the mouse to pan, scroll to zoom, Esc to close.
 * NOTE: the mouse/render method signatures below follow the 1.21.9+ style; if 26.2 differs,
 * the compiler will tell you exactly what to adjust.
 */
public class WorldMapScreen extends Screen {
    private static final int TEX = 512;
    private static final int[] ZOOMS = {1, 2, 4, 8, 16}; // blocks per pixel

    private final MapStore store;
    private final MapTexture texture;
    private int zoomIndex = 0;
    private double centerX, centerZ;

    public WorldMapScreen(MapStore store, MapTexture texture, int startX, int startZ) {
        super(Component.literal("World Map"));
        this.store = store;
        this.texture = texture;
        this.centerX = startX;
        this.centerZ = startZ;
        refresh();
    }

    private void refresh() {
        texture.paint(store, (int) Math.round(centerX), (int) Math.round(centerZ), ZOOMS[zoomIndex]);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        // screen pixels -> map pixels -> blocks
        double scale = (double) Math.min(width, height) / TEX;
        centerX -= (dx / scale) * ZOOMS[zoomIndex];
        centerZ -= (dy / scale) * ZOOMS[zoomIndex];
        refresh();
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        int old = zoomIndex;
        if (scrollY > 0) zoomIndex = Math.max(0, zoomIndex - 1);
        else if (scrollY < 0) zoomIndex = Math.min(ZOOMS.length - 1, zoomIndex + 1);
        if (old != zoomIndex) refresh();
        return true;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0xFF000000);

        int side = Math.min(width, height);
        int x0 = (width - side) / 2;
        int y0 = (height - side) / 2;
        g.blit(RenderPipelines.GUI_TEXTURED, texture.id, x0, y0, 0f, 0f, side, side, TEX, TEX);

        // player marker
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            double scale = (double) side / TEX;
            double px = ((mc.player.getX() - centerX) / ZOOMS[zoomIndex] + TEX / 2.0) * scale + x0;
            double py = ((mc.player.getZ() - centerZ) / ZOOMS[zoomIndex] + TEX / 2.0) * scale + y0;
            if (px >= x0 && px < x0 + side && py >= y0 && py < y0 + side) {
                g.fill((int) px - 2, (int) py - 2, (int) px + 3, (int) py + 3, 0xFFFF508C);
                g.fill((int) px - 1, (int) py - 1, (int) px + 2, (int) py + 2, 0xFFFFFFFF);
            }
        }

        g.drawString(font,
                "X " + (int) centerX + "  Z " + (int) centerZ + "   1px = " + ZOOMS[zoomIndex] + " block(s)   [drag: pan, scroll: zoom]",
                6, 6, 0xFFFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
