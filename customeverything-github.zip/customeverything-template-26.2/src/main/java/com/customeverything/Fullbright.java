package com.customeverything;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Fullbright without touching rendering internals: keeps a hidden, client-side-only
 * Night Vision effect on the local player. The server never sees it.
 */
public final class Fullbright {
    private static boolean enabled = false;
    private static boolean addedByUs = false;

    public static boolean isEnabled() { return enabled; }

    public static void toggle(Minecraft mc) {
        enabled = !enabled;
        if (!enabled) removeEffect(mc.player);
        if (mc.player != null) {
            mc.player.displayClientMessage(
                    net.minecraft.network.chat.Component.literal("Fullbright: " + (enabled ? "ON" : "OFF")), true);
        }
    }

    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || !enabled) return;
        if (!p.hasEffect(MobEffects.NIGHT_VISION)) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,
                    MobEffectInstance.INFINITE_DURATION, 0, false, false, false));
            addedByUs = true;
        }
    }

    private static void removeEffect(LocalPlayer p) {
        if (p != null && addedByUs) {
            p.removeEffect(MobEffects.NIGHT_VISION);
        }
        addedByUs = false;
    }
}
