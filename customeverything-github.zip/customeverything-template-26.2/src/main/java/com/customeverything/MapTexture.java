package com.customeverything;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

/** A small helper that owns a dynamic texture we repaint from a MapStore. */
public final class MapTexture {
    public final int size;
    public final Identifier id;
    private final NativeImage image;
    private final DynamicTexture texture;

    public MapTexture(String name, int size) {
        this.size = size;
        this.id = Identifier.fromNamespaceAndPath("customeverything", name);
        this.image = new NativeImage(size, size, true);
        this.texture = new DynamicTexture(() -> "customeverything_" + name, image);
        Minecraft.getInstance().getTextureManager().register(id, texture);
    }

    /**
     * Paints the texture so its centre pixel is block (centerX, centerZ) and each pixel covers
     * `blocksPerPixel` blocks. Unexplored areas are dark.
     */
    public void paint(MapStore store, int centerX, int centerZ, int blocksPerPixel) {
        int half = size / 2;
        for (int py = 0; py < size; py++) {
            for (int px = 0; px < size; px++) {
                int bx = centerX + (px - half) * blocksPerPixel;
                int bz = centerZ + (py - half) * blocksPerPixel;
                int c = store.colorAt(bx, bz);
                if (c == 0) c = 0xFF0B0814;
                image.setPixel(px, py, c);
            }
        }
        texture.upload();
    }
}
