package com.customeverything;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class CustomEverythingClient implements ClientModInitializer {
    private static final int MINIMAP_BLOCKS = 128;   // blocks shown across the minimap
    private static final int MINIMAP_SCREEN = 112;   // minimap size on screen (GUI px)

    private static KeyMapping keyFullbright, keyWorldMap, keyMinimap;
    private static boolean minimapVisible = true;

    private final Map<String, MapStore> stores = new HashMap<>();
    private MapTexture minimapTex;
    private MapTexture worldTex;
    private int tickCounter = 0;
    private int scanIndex = 0;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category cat = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("customeverything", "main"));
        keyFullbright = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.customeverything.fullbright", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, cat));
        keyWorldMap = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.customeverything.worldmap", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, cat));
        keyMinimap = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.customeverything.minimap", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_N, cat));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("customeverything", "minimap"),
                (graphics, tickDelta) -> renderMinimap(graphics));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> saveAll());
    }

    // ------------------------------------------------------------------ store handling

    private String worldId(Minecraft mc) {
        String base;
        if (mc.getCurrentServer() != null) base = mc.getCurrentServer().ip;
        else if (mc.getSingleplayerServer() != null) base = "sp_" + mc.getSingleplayerServer().getWorldData().getLevelName();
        else base = "unknown";
        return base.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private File fileFor(String id) {
        return new File(FabricLoader.getInstance().getConfigDir().toFile(), "customeverything/maps/" + id + ".bin");
    }

    private MapStore currentStore(Minecraft mc) {
        ClientLevel level = mc.level;
        if (level == null) return null;
        String id = worldId(mc) + "_" + level.dimension().identifier().toString().replace(':', '_');
        return stores.computeIfAbsent(id, k -> MapStore.load(fileFor(k)));
    }

    private void saveAll() {
        for (Map.Entry<String, MapStore> e : stores.entrySet()) {
            if (e.getValue().isDirty()) e.getValue().save(fileFor(e.getKey()));
        }
        stores.clear();
    }

    // ------------------------------------------------------------------ ticking

    private void onTick(Minecraft mc) {
        while (keyFullbright.consumeClick()) Fullbright.toggle(mc);
        while (keyMinimap.consumeClick()) minimapVisible = !minimapVisible;
        while (keyWorldMap.consumeClick()) openWorldMap(mc);

        Fullbright.tick(mc);

        if (mc.player == null || mc.level == null) return;
        MapStore store = currentStore(mc);
        if (store == null) return;
        tickCounter++;

        // scan a couple of chunks per tick, cycling through the 9x9 chunks around the player
        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;
        for (int i = 0; i < 3; i++) {
            int n = scanIndex++ % 81;
            int cx = pcx + (n % 9) - 4;
            int cz = pcz + (n / 9) - 4;
            store.scanChunk(mc.level, cx, cz, mc.player.getBlockY());
        }

        // autosave about once a minute
        if (tickCounter % 1200 == 0 && store.isDirty()) {
            String id = worldId(mc) + "_" + mc.level.dimension().identifier().toString().replace(':', '_');
            store.save(fileFor(id));
        }

        if (minimapTex == null) minimapTex = new MapTexture("minimap", MINIMAP_BLOCKS);
        if (tickCounter % 4 == 0) {
            minimapTex.paint(store, mc.player.getBlockX(), mc.player.getBlockZ(), 1);
        }
    }

    private void openWorldMap(Minecraft mc) {
        if (mc.player == null) return;
        MapStore store = currentStore(mc);
        if (store == null) return;
        if (worldTex == null) worldTex = new MapTexture("worldmap", 512);
        mc.setScreen(new WorldMapScreen(store, worldTex, mc.player.getBlockX(), mc.player.getBlockZ()));
    }

    // ------------------------------------------------------------------ minimap HUD

    private void renderMinimap(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (!minimapVisible || minimapTex == null || mc.player == null || mc.options.hideGui) return;

        int size = MINIMAP_SCREEN;
        int x = g.guiWidth() - size - 8;
        int y = 8;

        g.fill(x - 2, y - 2, x + size + 2, y + size + 2, 0xFF5A4A82);   // border
        g.blit(RenderPipelines.GUI_TEXTURED, minimapTex.id, x, y, 0f, 0f, size, size,
                MINIMAP_BLOCKS, MINIMAP_BLOCKS);

        // player marker in the centre
        int cx = x + size / 2, cy = y + size / 2;
        g.fill(cx - 2, cy - 2, cx + 3, cy + 3, 0xFFFF508C);
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);

        g.drawCenteredString(mc.font, "N", cx, y + 2, 0xFFFFFFFF);
        g.drawString(mc.font, mc.player.getBlockX() + ", " + mc.player.getBlockY() + ", " + mc.player.getBlockZ(),
                x, y + size + 5, 0xFFFFFFFF);
    }
}
